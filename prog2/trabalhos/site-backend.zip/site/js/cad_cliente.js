
document.getElementById("form-contato").onsubmit = validaCadastro;

function validaCadastro(){
	var contErro = 0;

	// validação do campo nome
	var nome = document.getElementById("nome");
	var erro_nome = document.getElementById("msg-nome");
	if((nome.value == "") || (nome.value.indexOf(" ") == -1)){
		erro_nome.innerHTML = "Por favor digite o Nome completo";
		erro_nome.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_nome.style.display = "none";
	}

	// validação do campo email
	var email = document.getElementById("email");
	var erro_email = document.getElementById("msg-email");
	if((email.value == "") || (email.value.indexOf("@") == -1)){
		erro_email.innerHTML = "Por favor digite o E-mail";
		erro_email.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_email.style.display = 'none';
	}

	// validação do campo duvida
	var duvida = document.getElementById("duvida");
	var erro_duvida = document.getElementById("msg-duvida");
	if(duvida.value == ""){
		erro_duvida.innerHTML = "Por favor digite sua dúvida";
		erro_duvida.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_duvida.style.display = "none";
	}
	// validação do checkbox
	var concordo = document.getElementById("concordo");
	var erro_concordo = document.getElementById("msg-concordo");
	if(!concordo.checked){
		erro_concordo.innerHTML = "Você precisa concordar com os termos de uso do site";
		erro_concordo.style.display = 'block';
		contErro+=1;
	}
	else{
		erro_concordo.style.display = 'none';
	}		

	if(contErro > 0)
		return false;
	else
		alert("Cadastro efetuado com sucesso"); // será removido posteriormente
}
