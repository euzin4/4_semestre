document.getElementById("exibeMenu").onclick = function(){
	var menu = document.getElementsByClassName("menu-superior")[0];
	if(menu.style.display == 'block')
		menu.style.display = 'none';
	else
		menu.style.display = 'block';
};

document.body.onresize = function(){
    var w = window.outerWidth;
    var menu = document.getElementsByClassName("menu-superior")[0];
    if (w >= 900){
		menu.style.display = 'block';
    } else{
		menu.style.display = 'none';    	
    }
};

function excat(){
	var cat = document.getElementById("categorias");
	if (cat.style.display == 'block')
		cat.style.display = 'none';
	else
		cat.style.display = 'block';

	var seta = document.getElementById("seta");
	if (seta.alt == "setaB"){
		seta.src = "imagens/seta_cima.png";
		seta.alt = "setaC";
	}
	else  {
		seta.src = "imagens/seta_baixo.png";
		seta.alt = "setaB";
	}
};