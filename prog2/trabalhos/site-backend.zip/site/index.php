<?php
	include "includes/cabecalho.php";
	include "includes/menu-superior.php";
?>
	<main>
		<?php
			include "includes/menu-esq.php";
		?>
		<section id="conteudo">
			<div class="listaProd">
				<div class="topo_lista">
					<h4>Ofertas</h4>
					<a class="link_mais" href="selecao.php?ofertas=1">Ver mais<img class="setaM" src="imagens/seta_mais.png" alt="mais"></a>
				</div>
				<?php
					$sqllist="select * from produto where pd_desconto > 0 order by pd_desconto DESC LIMIT 4";
					include "includes/lista-produtos.php";
				?>
			</div>
			<div class="listaProd">
				<div class="topo_lista">
					<h4>Mais vendidos</h4>
					<a class="link_mais" href="selecao.php?mvend=1">Ver mais<img class="setaM" src="imagens/seta_mais.png"  alt="mais"></a>
				</div>
				<?php
					$sqllist="select * from produto order by pd_nvendas DESC LIMIT 4";
					include "includes/lista-produtos.php";
				?>
			</div>
			<div class="listaProd">
				<div class="topo_lista">
					<h4>Novidades</h4>
					<a class="link_mais" href="selecao.php?novidades=1">Ver mais<img class="setaM" src="imagens/seta_mais.png" alt="mais"></a>
				</div>
				<?php
					$sqllist="select * from produto order by pd_dtadc DESC LIMIT 4";
					include "includes/lista-produtos.php";
				?>
			</div>
		</section>
	</main>
<?php
	include "includes/rodape.php";
?>