		<div id="exibeCat" class="catg" onclick="excat()">
			<h3>Categorias</h3>
			<img id="seta" src="imagens/seta_baixo.png" alt="setaB" style="width: 50px; padding-left: 15px;">
		</div>
		<section id="categorias" class="catg">
			<?php
				$sqlcat="select * from categoria";
				$resultado = mysqli_query($conexao, $sqlcat);
				while ($categoria = mysqli_fetch_array($resultado)){
			?>
			<a href="selecao.php?categoria=<?=$categoria['ct_cod'];?>&nome=<?=$categoria['ct_nome'];?>"><?=$categoria['ct_nome'];?></a>
			<?php
				}
			?>
		</section>