	<header>
		<img id="logo" src="imagens/logo.png" alt="logo">
		<div><img id="exibeMenu" src="imagens/menu.png" alt="menu"></div>
		<nav class="menu-superior">
			<ul>
				<li><a href="index.php">Início</a></li>
				<li><a href="selecao.php?ofertas=1">Ofertas</a></li>
				<li><a href="selecao.php?mvend=1">Mais vendidos</a></li>
				<li><a href="selecao.php?novidades=1">Novidades</a></li>
				<li><a href="formulario.html">Entre em contato</a></li>
			</ul>
		</nav>
		<a href="#"><img id="carrinho" src="imagens/carrinho.png" alt="carrinho"></a>
		<div><img id="busca" src="imagens/lupa.png" alt="busca"></div>
	</header>