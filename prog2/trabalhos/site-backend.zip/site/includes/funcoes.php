<?php
	function mostraPreco($valor, $desconto){
		if($desconto == 0){
			return "<span class='precoFinal'>R$ ".str_replace(".", ",", number_format($valor, 2))."</span>";
		}
		else{
			return "De R$ <del>".str_replace(".", ",", number_format($valor, 2))."</del> por 
			<span class='precoFinal'>R$ ".str_replace(".", ",", number_format(($valor - $desconto), 2))."</span>";
		}
	}
?>