	<footer class="rodape">
		<p>Chapecó-SC</p>
		<p>Av.Getúlio Vargas - Centro</p>
		<p>Telefone: 3333-3333</p>
	</footer>
	<script src="js/functions.js"></script>
</body>
</html>