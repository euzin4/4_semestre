				<?php
					$reslist = mysqli_query($conexao, $sqllist);
					while ($prodlist = mysqli_fetch_array($reslist)){
						if($prodlist['pd_imagem'] == ''){
							$imagem = "indisponivel.jpg";
						}else{
							$imagem = $prodlist['pd_imagem'];
						}
				?>
				<a href="produto.php?id=<?=$prodlist['pd_cod'];?>">
					<figure class="produto">
						<img class="imgProd" src="imagens/produtos/<?=$imagem;?>" alt="produto">
						<figcaption class="nomeProd">
							<?=$prodlist['pd_nome'];?>
							<div class="valProd"><?=mostraPreco($prodlist['pd_preco'], $prodlist['pd_desconto']);?></div>
						</figcaption>
					</figure>
				</a>
				<?php
					}
				?>