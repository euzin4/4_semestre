<?php
	if (isset($_GET['categoria'])) {
		$categoria = $_GET['categoria'];
		$nome = $_GET['nome'];
		$sqllist = "select * from produto join prod_cat on produto.pd_cod=prod_cat.pd_cod where prod_cat.ct_cod = $categoria";
	}
	else if (isset($_GET['ofertas'])) {	//ofertas
		$ofertas = $_GET['ofertas'];
		$nome = "Ofertas";
		$sqllist = "select * from produto where pd_desconto > 0 order by pd_desconto DESC";
	}
	else if (isset($_GET['mvend'])) {	//mais vendidos
		$mvend = $_GET['mvend'];
		$nome = "Mais vendidos";
		$sqllist = "select * from produto order by pd_nvendas DESC";
	}
	else if (isset($_GET['novidades'])) {	//novidades
		$novidades = $_GET['novidades'];
		$nome = "Novidades";
		$sqllist = "select * from produto order by pd_dtadc DESC";
	}
	
?>
<?php
	include "includes/cabecalho.php";
	include "includes/menu-superior.php";
?>
	<main>
		<?php
			include "includes/menu-esq.php";
		?>
		<section id="conteudo">
			<div class="listaProd">
				<div class="topo_lista">
					<h4><?=$nome;?></h4>
				</div>
				<?php
					//'$sqllist' foi setado no topo da página
					include "includes/lista-produtos.php";
				?>
			</div>
		</section>
	</main>
<?php
	include "includes/rodape.php";
?>