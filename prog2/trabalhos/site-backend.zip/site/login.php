<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Construfer - Login</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
	<link rel="icon" type="image/png" href="imagens/icon.png">
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
</head>
<body>
	<main>
		<div id="login">
			<p id="tlog">Acesso</p>
			<form action="verificar.php" method="post">
				<label for="user">Usuário:</label>
				<input style="margin-left: 9px;" type="text" name="user"><br><br>
				<label for="senha">Senha:</label>
				<input style="margin-left: 20px;" type="password" name="senha"><br><br>
				<input style="margin-left: 35%; margin: : 15px; width:90px;" type="submit" name="logon" value="entrar">

			</form><br>
			<a class="link" href="">Novo cadastro</a>
			<a class="link" href="">Esqueci minha senha</a>
		</div>
	</main>
	<script src="js/functions.js"></script>
</body>
</html>