<?php
	include "includes/cabecalho.php";
	include "includes/menu-superior.php";
	$id = $_GET['id'];
	$sqlprod = "select * from produto where pd_cod = $id";
	$resprod = mysqli_query($conexao, $sqlprod);
	$produto = mysqli_fetch_array($resprod);
	$nome = $produto['pd_nome'];
	if ($produto['pd_imagem'] == ''){
		$imagem = "indisponivel.jpg";
	}else{
		$imagem = $produto['pd_imagem'];
	}
?>
	<main>
		<?php
			include "includes/menu-esq.php";
		?>
		<section id="conteudo">
			<div class="listaProd">
				<div class="topo_lista">
					<h4><?=$nome;?></h4>
				</div>
				<img src="imagens/produtos/<?=$imagem;?>" style="float: left; width: 500px; height: 500px; padding-right: 20px">
				<h5>Preço</h5>
				<div class="valProd" style="font-size: 20px;"><?=mostraPreco($produto['pd_preco'], $produto['pd_desconto']);?></div><br>
				<form method="post" action="">
					<input type="hidden" name="id" value="<?=$produto['pd_cod'];?>">
					<input type="hidden" name="nome" value="<?=$produto['pd_nome'];?>">
					<label for="quant" style="font-size: 20px;">Quantidade:</label><br>
					<input type="number" name="quant" min="1" value="1" style="width: 50px;"><br>
					<input type="submit" name="adicionar" value="Adicionar ao Carrinho" id="botCar">
				</form>
				<div style="clear: both;">
				<span style="font-size: 20px;">Descrição:</span>
				<span style="font-size: 20px;"><?=$produto['pd_descricao'];?></span>
				</div>
			</div>
		</section>
	</main>
<?php
	include "includes/rodape.php";
?>