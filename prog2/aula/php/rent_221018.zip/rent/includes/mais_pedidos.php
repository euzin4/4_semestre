		<aside class="col-3">
			<h2>Mais pedidos</h2>
			<!-- container de mais pedidos -->
			<div class="lista-produtos">
				<!-- um produto -->
				<div class="produto">
					<a href="produto.html">
						<figure>
							<img src="img/produtos/serra.jpg" alt="miniatura1">
							<figcaption>Serra elétrica<span class="preco">R$ 20,00</span></figcaption>
						</figure>
					</a>
				</div>  
				<!-- fim produto -->
				
				<!-- adicione mais produtos --> 				
			</div>
		</aside>