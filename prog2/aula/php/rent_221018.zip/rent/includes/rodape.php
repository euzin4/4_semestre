	<!-- rodape -->
	<footer><p>Rent a Tool - Chapecó/SC</p>
		<ul class="social">
			<li><a href="http://facebook.com/rentatool"><img src="img/facebook.png" alt="Facebook"></a></li>
			<li><a href="http://twitter.com/rentatool"><img src="img/twitter.png" alt="Twitter"></a></li>
			<li><a href="http://plus.google.com/rentatool"><img src="img/googleplus.png" alt="Google+"></a></li>
		</ul>
		<div id="ajuda">Precisa de ajuda? <span id="fechar">x</span></div>
	</footer>
	<!-- fim rodape -->
	<script src="js/functions.js"></script>
</body>
</html>