<?php
	include "includes/cabecalho.php";
?>
	<div class="container">
		<?php
			include "includes/menu_lateral.php";
		?>
	<section class="col-2">
		<?php
			if(!isset($_SESSION['carrinho'])){
				echo "<h2>Seu carrinho está vazio. ";
			}else{
		?>
				<h2>Meu carrinho</h2>
				<div class="itemCarrinho">
					<span class="produtoCarrinho"><strong>Produto</strong></span>
					<span class="qtdeCarrinho"><strong>Quantidade</strong></span>
					<span class="precoCarrinho"><strong>Valor</strong></span>
				</div>
			<?php
				$total = 0;
				foreach ($_SESSION['carrinho'] as $id => $item) {
			?>
					<div class="itemCarrinho">
						<span class="produtoCarrinho"><?=$item['nome'];?></span>
						<span class="qtdeCarrinho"><?=$item['quantidade'];?></span>
						<span class="precoCarrinho"><?=$item['valorFinal'];?></span>
						<!--<span class="excuirCarrinho"><?= ?></span> --------------------------terminar -->
					</div>
				<?php
					$total += ($item['quantidade'] * $item['valorFinal']);
				}
				?>
				<div class="itemCarrinho total">
					<span>Total:</span>
					<span class="precoCarrinho"><strong><?=$total;?></strong></span>
				</div>
				<div class="botoes">
					<a href="index.php"><button>Continuar comprando</button></a>
					<a href="fecharPedido.php"><button>Finalizar Pedido</button></a>
				</div>
			<?php
			}
			?>
		
	</section>
		