<!doctype html>
<html lang="pt-br">
  <head>
  	<meta charset="utf-8">
  	<title>Meu site</title>
  </head>
  <body>
  	<h2>Acesso</h2>
  	<br><br>
  	<form action="verificacao.php" method="post">	<!--manda os dados para o arquivo verificacao.php via POST-->
  		Login: <input type="text" name="login"><br>		<!--o nome das variaveis enviadas são definidas pelo 'name' no <input> -->
  		Senha: <input type="password" name="senha"><br>
      <div style="color: red">	<!--recebe o valor da variavel 'erro' da pagina verificacao.php via redirecionamento -->
        <?php
        if(isset($_GET['erro'])){
          if($_GET['erro'] == 1)
            echo "Login incorreto";
          elseif($_GET['erro'] == 2)
            echo "Senha incorreta";
        }
        ?>
      </div>
  		<input type="submit" value="Entrar">
  	</form>
  	<br>
  	<a href="../cad_cliente.html">Quero me cadastrar</a>
  	<a href="#">Esqueci minha senha</a>
  </body>
</html>