	<!-- rodape -->
	<footer><p>Último acesso em: 17/09/2018</p>	</footer>
	<script src="../js/functionsAdm.js"></script>
</body>
</html>