<?php
include "includes/cabecalho.php";
?>

	<!-- area central com 3 colunas -->
	<div class="container">
		<?php
		include "includes/menu_lateral.php";
		?>		

		<section class="col-2">
			<?php
			include "includes/conexao.php";
			$id = $_GET['id'];
			$sql = "select id, nome, imagem, descricao, tensao, valor, desconto, catMarcenaria, catJardinagem, catLimpeza, catEscritorio, catMecanica, catOutros from produto where id = $id";
			$sqlFab = "select fabricante.nome from fabricante join produto on fabricante.id=produto.idFabricante where produto.id = $id;";
			$resFab = mysqli_query($conexao, $sqlFab);
			$fabricante = mysqli_fetch_array($resFab);
			$resultado = mysqli_query($conexao, $sql);
			$produto = mysqli_fetch_array($resultado);
			if(isset($_GET['secao'])){
				$categoriaSelecionada = $_GET['secao'];
				$titulo = $CATEGORIAS[$categoriaSelecionada];
			}
			elseif(isset($_GET['busca'])){
				$titulo = "Resultado da busca por \"{$_GET['busca']}\" ";
			}
			else{
				$titulo = $produto['nome'];
			}
			?>
			<h2><?=$titulo?></h2>

			<!-- container de produtos -->
			<div class="lista-produtos">
				<!-- um produto -->
				<?php
				include "includes/functions.php";
				if(isset($categoriaSelecionada))
					$sql.= " where $categoriaSelecionada IS TRUE";
				elseif(isset($_GET['busca']))
					$sql.=" where nome like '%{$_GET['busca']}%'";
				else
					$sql.= " order by id desc limit 10"; // novidades

				//echo $sql;

				$resultado = mysqli_query($conexao, $sql);
				if(mysqli_num_rows($resultado) == 0){
					echo "<p>Nenhum produto encontrado</p>";
				}
				else{
					$produto = mysqli_fetch_array($resultado);
					?>
				    <div class="pagProduto">
				    	<div>
							<img id="imagemProd" src="img/produtos/<?=mostraImagem($produto['imagem']);?>" alt="<?=$produto['nome'];?>">
						</div>
						<div id="col-p">
							<span class="preco">
								<h2>Preço</h2>
								<?=mostraPreco($produto['valor'], $produto['desconto']);?>			
							</span>
							<br>
							<form action="adiciona.php" method="GET" id="carrinho">
								<label for="prodId"></label>
								<input style="display: none;" type="text" name="id" value="<?=$id?>">
								<label for="quantidade" class="label-alinhado">Quantidade:</label>
								<input style="width: 50px" type="number" id="quantidade" name="quantidade" value="1" min="1">
								<br>
								<input type="submit" id="botCar" value="Adicionar ao carrinho">
							</form>
						</div>
						<div id="desc">
							<p>Fabricante: <?=$fabricante['nome'];?></p>
							<p>Tensão: <?=$produto['tensao'];?> volts</p>
							<p>Descrição: <?=$produto['descricao'];?></p>
							<p class="detalhes">Categorias: <span class="cat-names">&nbsp;
								<?php
									$categorias = array();
									if($produto['catMarcenaria']==1){
										array_push($categorias, "Marcenaria");							
									}
									if($produto['catJardinagem']==1){
										array_push($categorias, "Jardinagem");							
									}
									if($produto['catLimpeza']==1){
										array_push($categorias, "Limpeza");							
									}
									if($produto['catEscritorio']==1){
										array_push($categorias, "Escritorio");							
									}
									if($produto['catMecanica']==1){
										array_push($categorias, "Mecanica");							
									}						
									if($produto['catOutros']==1){
										array_push($categorias, "Outros");							
									}
																					
									foreach ($categorias as $lista){
										echo "$lista&nbsp;&nbsp;  ";
									}						
													
								?>
							</span></p>
						</div>
				    </div> 
				    <?php						
				}
				?>
			</div>			
		</section>
	<?php
	include "includes/mais_pedidos.php";
	?>
	</div>
	<!-- fim area central -->
<?php
include "includes/rodape.php";
?>
