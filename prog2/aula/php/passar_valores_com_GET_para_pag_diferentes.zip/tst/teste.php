<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<form action="teste2.php" method="GET">
		<input type="text" name="nome">
		<input type="number" name="numero">
		<input type="submit">
	</form>
</body>
</html>