<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$nome = $_GET['nome'];
		$num = $_GET['numero'];
		echo "$nome<br>$num";
	?>
</body>
</html>