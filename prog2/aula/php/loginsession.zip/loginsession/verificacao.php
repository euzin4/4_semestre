<?php
	include "../includes/conexao.php";
	
	if($_POST['login'] != 'admin'){		//caso a variavel 'login' não possua o valor correto 
		header("Location: login.php?erro=1");	//redireciona para a pagina login.php com a variavel 'erro' com valor 1
	}
	else{
		if($_POST['senha'] != '1234'){		//caso a variavel 'senha' não possua o valor correto
			header("Location: login.php?erro=2");	//redireciona para a pagina login.php com a variavel 'erro' com valor 2
		}
		else{ // login e senha corretos
			session_start(); // abre uma nova sessao
			$_SESSION['login'] = $_POST['login']; // armazena login na sessao
			$_SESSION['inicio'] = date("H:i:s"); // armazena horario na sessao
			header("Location: restrito.php");	//redireciona para a pagina restrito.php
		}
	}
?>