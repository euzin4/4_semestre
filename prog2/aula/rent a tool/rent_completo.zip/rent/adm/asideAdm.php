			<aside>
				<ul class='itens'>
					<li>Total de Produtos: 150</li>
					<li>Locados: 99</li>
					<li>Disponíveis: 51</li>
				</ul>
			</aside>