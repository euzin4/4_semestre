<?php
$CATEGORIAS = array(
	// "nome no bd" => "nome para exibição"
	"catMarcenaria" => "Marcenaria",
	"catJardinagem" => "Jardinagem",
	"catLimpeza" 	=> "Limpeza",
	"catEscritorio" => "Escritório",
	"catMecanica" 	=> "Mecânica",
	"catOutros" 	=> "Outros"
);
?>