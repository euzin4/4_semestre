<?php
	include "includes/conexao.php";

	$sql = "select id, login, senha, nome from cliente";
	$resultado = mysqli_query($conexao, $sql);
	$senha = md5($_POST['senha']);

	while($logins = mysqli_fetch_array($resultado)){
		if($_POST['login'] != $logins['login']){		//caso a variavel 'login' não possua o valor correto 
			header("Location: login.php?erro=1");	//redireciona para a pagina login.php com a variavel 'erro' com valor 1
		}
		else{
			if($senha != $logins['senha']){		//caso a variavel 'senha' não possua o valor correto
				header("Location: login.php?erro=2");	//redireciona para a pagina login.php com a variavel 'erro' com valor 2
			}
			else{ // login e senha corretos
				session_start(); // abre uma nova sessao
				$_SESSION['id'] = $logins['id']; 
				$_SESSION['nome'] = $logins['nome'];
				header("Location: index.php");	//redireciona para a pagina restrito.php
			}
		}
	}
?>